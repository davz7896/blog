<?php $__env->startSection('title','Songs'); ?>

<?php $__env->startSection('body'); ?>
	<?php echo e('Song To God Everything'); ?>

	<?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($song->title); ?>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>