@extends('layout.app')

@section ('title','Songs')

@section('body')
	{{'Song To God Everything'}}
	@foreach ($songs as $song)
		{{$song->title}}
	@endforeach 
@endsection