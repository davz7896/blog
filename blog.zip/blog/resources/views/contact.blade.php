</html>
<head>
<meta charset="utf-8" />
<title>Nyekrip - Membuat Menu Dropdown</title>

<link href="style.css" rel="stylesheet" />

</head>
<body>
<div id="wrapper">

</div>

<div id="mid_index">

	<p align="center"><img src="gambar perumahan/a.png" width="400" height="100"></p>
	<p align="center"><font face="Comic Sans MS" size="3" color="#000000">Alamat :Perumahan Kaweoron-Talun-Biltar-JawaTimur</p>
	<nav>
	<ul>
		<li><a href="beranda"><font  face="Comic Sans MS" color=" #000000" size="3">Beranda</a></li>
		<li><a href="about"><font  face="Comic Sans MS" color=" #000000" size="3">Tentang</a></li>
		<li><a href="schedule"><font  face="Comic Sans MS" color=" #000000" size="3">Jadwal Kegiatan Warga</a></li>
		<li><a href="event"><font  face="Comic Sans MS" color=" #000000" size="3">Acara</a></li>
		<li><a href="album"><font  face="Comic Sans MS" color=" #000000" size="3">Album</a></li>
		<li><a href="store"><font  face="Comic Sans MS" color=" #000000" size="3">Toko</a></li>
		<li><a href="contact"><font  face="Comic Sans MS" color=" #000000" size="3">Kontak</a></li>
	</ul>
	</nav>
		<table border="4" bgcolor="A9C5EB" align="center" height="500" width="400" cellpadding="20">
	<tr>
	<td>
	<b><font color="black" size="10"> Masuka Persyaratan </font></b>
	<p> Masukan Biodata anda untuk menghubungi kita	</p>
	<input type="text" Name="nama depan" size="23" placeholder="Nama Depan">
	<input type="text" Name="nama belakang" size="21" placeholder="Nama Belakang"><br><br>
	<input type="text" Name="umur" size="49" placeholder="Umur"><br><br>
	<input type="text" Name="email" size="49" placeholder="Email Anda"><br><br>
	<input type="radio" name="Kelamin" value="L">Laki Laki
	<input type="radio" name="Kelamin" value="P">Perempuan
	<br><br>
	<textarea name="komentar" cols="50" rows="10" id="komentar" placeholder="Subject"></textarea>
	<br></br>
	<input value="Kirim" style="background-color: 4985D0; height: 50; width: 150;"type="submit">
	</td>
	</tr>
</table>
		<br><
		<table border="0" align="center">
			<tr>
			<td><p align="center"><img src="gambar perumahan/perumahan1.jpg" Width="400" Height="200"align="center"><p></td>
			<td><p align="center"><img src="gambar perumahan/perumahan2.jpg" Width="400" Height="200"align="center"><p></td>
			</tr>
			
		</table>
	<p>Cari alamat rumah yang anda inginkan</p>
	<p align="center"><input class="search" type="text" placeholder="Cari..." required>
	<input class="button" type="button" value="Cari"></p>	
<table border="0" align="center">
			<tr>
			<td width="75"><a href="https://www.facebook.com/"><img src="gambar perumahan/facebook.png" width="50"></a></td>
			<td><a href="https://www.instagram.com/"><img src="gambar perumahan/instagram.jpg" width="68	"></a></td>
			</tr>			
</table>

</div>

</body>
</html>