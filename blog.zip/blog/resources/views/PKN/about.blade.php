</html>
<head>
<meta charset="utf-8" />
<title>Nyekrip - Membuat Menu Dropdown</title>

<link href="style.css" rel="stylesheet" />

</head>
<body>
<div id="wrapper">

</div>

<div id="mid_index">
	<p align="center"><img src="gambar perumahan/a.png" width="400" height="100"></p>
	<p align="center"><font face="Comic Sans MS" size="3" color="#000000">Alamat :Perumahan Kaweoron-Talun-Biltar-JawaTimur</p>	<nav>
	<ul>
		<li><a href="beranda.php"><font  face="Comic Sans MS" color=" #000000" size="3">Beranda</a></li>
		<li><a href="about.php"><font  face="Comic Sans MS" color=" #000000" size="3">Tentang</a></li>
		<li><a href="schedule.php"><font  face="Comic Sans MS" color=" #000000" size="3">Jadwal Kegiatan Warga</a></li>
		<li><a href="event.php"><font  face="Comic Sans MS" color=" #000000" size="3">Acara</a></li>
		<li><a href="album.php"><font  face="Comic Sans MS" color=" #000000" size="3">Album</a></li>
		<li><a href="store.php"><font  face="Comic Sans MS" color=" #000000" size="3">Toko</a></li>
		<li><a href="contact.php"><font  face="Comic Sans MS" color=" #000000" size="3">Kontak</a></li>
	</ul>
	</nav>
   <p style="text-align:justify;">
   <table border="0" align="center" style="float:right; margin:0 0px 0px 10;">
			<tr>
			<td height="450"><p align="center"><iframe width="300" height="450" src="http://www.youtube.com/embed/qF92x-coHeE" frameborder="0" allowfullscreen></iframe><p></td>
			</tr>
		</table>
		<img src="gambar perumahan/perumahan4.jpg" width="300" height="210" style="float:left; margin:0 8px 4px 0;"/><font align="center" size="2">Perumahan "Kaweron Pondok Delta" merupakan hasil kerja bareng antara PT. Kamilindo Sejahtera dengan PT. Graha Sarana Duta (anak perusahaan PT. Telkom Tbk). PT. Kamilindo Sejahtera merupakan perusahaan developer yang sudah berpengalaman selama bertahun-tahun mengelola perumahan mewah yang berlokasi di Blitar, Pandaan, Balikpapan,dan Banjarmasin.
		
Memiliki rumah di perumahan "Kaweron Pondok Delta" adalah sebuah investasi yang sangat menguntungkan. Lokasinya dikelilingi oleh berbagai macam fasilitas pendukung, sehingga membuat perumahan "Kaweron Pondok Delta" begitu prima. Misalnya: hanya 5 menit dari mall City of Tomorrow (Cito), 2 menit akses ke / dari jalan tol, 15 menit dari Bandara Juanda, 800 meter dari Carrefour Jl. Ahmad Yani. Sangat dekat dengan fasilitas pendidikan misalnya sekolah Al - Hikmah, Universitas Kristen Petra, Universitas Pelita Harapan (UPH), dll. Dan berdekatan dengan fasilitas peribadatan misalnya Masjid Agung Surabaya (MAS) dan Gereja Katolik Sakramen Maha Kudus. Guna menambah rasa aman dan nyaman, depan pintu gerbang telah berdiri pos Polisi sub Sektor Polsek Gayungan. 
Untuk memanjakan konsumen, "Kaweron Pondok Delta" juga memberikan fasilitas pendukung antara lain: bebas banjir, sertifikat HGB sudah pecah per kavling, pintu gerbang one gate system, club house syariah serta SPA syariah (yang pertama kali di Indonesia), serta fasilitas-fasilitas lain.
</p>
<br></br>
<table width="433" border="0" align="left" cellpadding="4" cellspacing="2">
    <tr>
      <td width="118"><div align="right">Nama</div></td>
      <td width="293"><input name="nama" type="text" id="nama" size="40" /></td>
    </tr>
    <tr>
      <td><div align="right">Email</div></td>
      <td><input name="email" type="text" id="email" size="40" /></td>
    </tr>
    <tr>
      <td><div align="right">Jenis Kelamin</div></td>
      <td><select name="select">
        <option value="1" selected="selected">Laki-laki</option>
        <option value="2">Perempuan</option>
      </select></td>
    </tr>
    <tr>
      <td><div align="right">Komentar</div></td>
      <td><textarea name="komentar" cols="30" rows="5" id="komentar"></textarea></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input name="kirim" type="submit" id="kirim" value="Kirim" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
  </br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br>
<table border="0" align="center">
			<tr>
			<td width="75"><a href="https://www.facebook.com/"><img src="gambar perumahan/facebook.png" width="50"></a></td>
			<td><a href="https://www.instagram.com/"><img src="gambar perumahan/instagram.jpg" width="68	"></a></td>
			</tr>			
</table>
</div>
</body>
</html>