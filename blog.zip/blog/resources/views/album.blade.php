</html>
<head>
<meta charset="utf-8" />
<title>Nyekrip - Membuat Menu Dropdown</title>

<link href="style.css" rel="stylesheet" />

</head>
<body>
<div id="wrapper">

</div>

<div id="mid_index">

	<p align="center"><img src="gambar perumahan/a.png" width="400" height="100"></p>
	<p align="center"><font face="Comic Sans MS" size="3" color="#000000">Alamat :Perumahan Kaweoron-Talun-Blitar-JawaTimur</p>
	<nav>
	<ul>
		<li><a href="beranda"><font  face="Comic Sans MS" color=" #000000" size="3">Beranda</a></li>
		<li><a href="about"><font  face="Comic Sans MS" color=" #000000" size="3">Tentang</a></li>
		<li><a href="schedule"><font  face="Comic Sans MS" color=" #000000" size="3">Jadwal Kegiatan Warga</a></li>
		<li><a href="event"><font  face="Comic Sans MS" color=" #000000" size="3">Acara</a></li>
		<li><a href="album"><font  face="Comic Sans MS" color=" #000000" size="3">Album</a></li>
		<li><a href="store"><font  face="Comic Sans MS" color=" #000000" size="3">Toko</a></li>
		<li><a href="contact"><font  face="Comic Sans MS" color=" #000000" size="3">Kontak</a></li>
	</ul>
	</nav>
		<br>
		<p align="center" ><font face="Comic Sans MS" size="4"/>Foto Kegiatan Lomba 17 Agustus 2016</p>
		<table border="0" align="center">
			<tr>
			<td><p align="center"><img src="gambar perumahan/lomba2.jpg" Width="400" Height="200"align="center"><p></td>
			</tr>
		</table>	
		<p align="center"><font size="2">What do pole vaulting, waitressing, youth pastoring, and dissecting sharks have in common?

 Well, nothing really...except that Jeniffer Dake has done them all! Her diverse background and life experiences provide natural connections with students, no matter where they have come from or where they are, and allow her to encourage them to live passionately for Christ in a way that impacts the world around them for eternity. As a tour pastor for Stacie Orrico, speaker on the Girls of Grace tour and in numerous high schools and church youth events as well as partnering with Michael W. Smith in teen ministry, Jeniffer has proven her ability to engage students with her honest and real approach to the daily challenges of life that we can turn into opportunities to share the powerful message of Christ. Her focus on lifestyle evangelism and the benefits of sexual purity are messages that the college students of today desperately need to hear.</p>
		</br>
		<p align="center" ><font face="Comic Sans MS" size="4"/>Foto Kegiatan Jalan Sehat Bersama 12 Desember 2016</p>
		<table border="0" align="center">
			<tr>
			<td><p align="center"><img src="gambar perumahan/JalanSehat.jpg" Width="400" Height="200"align="center"><p></td>
			</tr>
		</table>	
		<p align="center"><font size="2">What do pole vaulting, waitressing, youth pastoring, and dissecting sharks have in common?

 Well, nothing really...except that Jeniffer Dake has done them all! Her diverse background and life experiences provide natural connections with students, no matter where they have come from or where they are, and allow her to encourage them to live passionately for Christ in a way that impacts the world around them for eternity. As a tour pastor for Stacie Orrico, speaker on the Girls of Grace tour and in numerous high schools and church youth events as well as partnering with Michael W. Smith in teen ministry, Jeniffer has proven her ability to engage students with her honest and real approach to the daily challenges of life that we can turn into opportunities to share the powerful message of Christ. Her focus on lifestyle evangelism and the benefits of sexual purity are messages that the college students of today desperately need to hear.</p>
		</br>
		<p align="center" ><font face="Comic Sans MS" size="4"/>Foto Kegiatan Donor Darah 20 Januari 2017</p>
		<table border="0" align="center">
			<tr>
			<td><p align="center"><img src="gambar perumahan/donordarah2.jpg" Width="400" Height="200"align="center"><p></td>
			</tr>
		</table>	
		<p align="center"><font size="2">What do pole vaulting, waitressing, youth pastoring, and dissecting sharks have in common?

 Well, nothing really...except that Jeniffer Dake has done them all! Her diverse background and life experiences provide natural connections with students, no matter where they have come from or where they are, and allow her to encourage them to live passionately for Christ in a way that impacts the world around them for eternity. As a tour pastor for Stacie Orrico, speaker on the Girls of Grace tour and in numerous high schools and church youth events as well as partnering with Michael W. Smith in teen ministry, Jeniffer has proven her ability to engage students with her honest and real approach to the daily challenges of life that we can turn into opportunities to share the powerful message of Christ. Her focus on lifestyle evangelism and the benefits of sexual purity are messages that the college students of today desperately need to hear.</p>
	</br>
	<p align="center"><input class="search" type="text" placeholder="Cari..." required>
	<input class="button" type="button" value="Cari"></p>	
<table border="0" align="center">
			<tr>
			<td width="75"><a href="https://www.facebook.com/"><img src="gambar perumahan/facebook.png" width="50"></a></td>
			<td><a href="https://www.instagram.com/"><img src="gambar perumahan/instagram.jpg" width="68	"></a></td>
			</tr>			
</table>

</div>

</body>
</html>