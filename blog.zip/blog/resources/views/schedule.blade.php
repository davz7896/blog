</html>
<head>
<meta charset="utf-8" />
<title>Nyekrip - Membuat Menu Dropdown</title>

<link href="style.css" rel="stylesheet" />

</head>
<body>
<div id="wrapper">

</div>

<div id="mid_index">

	<p align="center"><img src="gambar perumahan/a.png" width="400" height="100"></p>
	<p align="center"><font face="Comic Sans MS" size="3" color="#000000">Alamat :Perumahan Kaweoron-Talun-Blitar-JawaTimur</p>
	<nav>
	<ul>
		<li><a href="beranda"><font  face="Comic Sans MS" color=" #000000" size="3">Beranda</a></li>
		<li><a href="about"><font  face="Comic Sans MS" color=" #000000" size="3">Tentang</a></li>
		<li><a href="schedule"><font  face="Comic Sans MS" color=" #000000" size="3">Jadwal Kegiatan Warga</a></li>
		<li><a href="event"><font  face="Comic Sans MS" color=" #000000" size="3">Acara</a></li>
		<li><a href="album"><font  face="Comic Sans MS" color=" #000000" size="3">Album</a></li>
		<li><a href="store"><font  face="Comic Sans MS" color=" #000000" size="3">Toko</a></li>
		<li><a href="contact"><font  face="Comic Sans MS" color=" #000000" size="3">Kontak</a></li>
	</ul>
	</nav>
	<p align="center"><font face="Engravers MT" size="5" color="#B8860B"/>Jadwal Kegiata Warga</p>

<table border="1" bgcolor=" #F4A460" align="center" width="800" height="100" cellpadding="20" cellspacing="2">
			<tr>
			<th><font  face="Comic Sans MS"/>No</th>
			<th><font  face="Comic Sans MS"/>Jadwal</th>
			<th><font  face="Comic Sans MS"/>Hari</th>
			<th><font  face="Comic Sans MS"/>Jam</th>
			<th><font  face="Comic Sans MS"/>Tanggal</th>
			<th><font  face="Comic Sans MS"/>Keterangan</th>
			</tr>
			<tr>
			<td><font  face="Comic Sans MS"/>1</td>
			<td><font  face="Comic Sans MS"/>Kerja Bakti</td>
			<td><font  face="Comic Sans MS"/>Minggu</td>
			<th><font  face="Comic Sans MS"/>06:00</th>
			<td><font  face="Comic Sans MS"/>20-2-2017</td>
			<td><font  face="Comic Sans MS"/>Mebawa peralatan kerja bakti : 1.Sapu Lidy 
											   2.Cangkul 
											   3.Sekop</td>
			</tr>
			<tr>
			<td><font  face="Comic Sans MS"/>2</td>
			<td><font  face="Comic Sans MS"/>Olahraga Voli antar gang</td>
			<td><font  face="Comic Sans MS"/>Sabtu</td>
			<th><font  face="Comic Sans MS"/>15:00</th>
			<td><font  face="Comic Sans MS"/>19-12-2017</td>
			<td><font  face="Comic Sans MS"/>Diikuti Oleh : 1. rang dewasa dan remaja 
							   2. perempuan dan laki laki</td>
			</tr>	
			<tr>
			<td><font  face="Comic Sans MS"/>3</td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
			</tr>	
			<tr>
			<td><font  face="Comic Sans MS"/>4</td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
			</tr>	
		</table>
</div>

</body>
</html>