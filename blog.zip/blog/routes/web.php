<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','PagesController@welcome');
Route::resource('songs','SongsControler');

Route::get('beranda', function () {
    return view('beranda');
});
Route::get('album', function () {
    return view('album');
});
Route::get('about', function () {
    return view('about');
});
Route::get('schedule', function () {
    return view('schedule');
});
Route::get('event', function () {
    return view('event');
});

Route::get('store', function () {
    return view('store');
});

Route::get('contact', function () {
    return view('contact');
});
